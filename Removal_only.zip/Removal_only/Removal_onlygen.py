from essentials import *
from packages import *
from Removal_only import *
import Removal_onlymain 

input_dir = "/content/data_removal_png"
output_mask_dir = "/content/mask_removal"
output_temp_dir = "/content/temp_removal"
output_crop_dir = "/content/crop_removal"
threshold_area = 10000
csv_file_path = "output.csv"
process_images_in_folder(input_dir, output_mask_dir, output_temp_dir, output_crop_dir, threshold_area, csv_file_path)

image_folder = "data_removal_png"
mask_folder = "mask_removal"
output_folder = "output_removal"
process_images(image_folder, mask_folder, output_folder)